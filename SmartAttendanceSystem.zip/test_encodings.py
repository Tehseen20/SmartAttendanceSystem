import pickle

with open("encodings.pkl", "rb") as f:
    encodings, names = pickle.load(f)

print(len(encodings))
print(names[:5])