"""
encode_faces.py — Encode all student face images into encodings.pkl
Place images in: dataset/<StudentName>/image1.jpg  image2.jpg ...
"""

import face_recognition
import os
import pickle

DATASET_PATH   = "dataset"
ENCODINGS_FILE = "encodings.pkl"

known_encodings = []
known_names     = []

if not os.path.isdir(DATASET_PATH):
    print(f"[ERROR] Dataset folder '{DATASET_PATH}' not found.")
    print("Create: dataset/<StudentName>/*.jpg")
    exit(1)

students = [s for s in os.listdir(DATASET_PATH)
            if os.path.isdir(os.path.join(DATASET_PATH, s))]

if not students:
    print("[ERROR] No student folders found inside 'dataset/'")
    exit(1)

print(f"Found {len(students)} student(s): {', '.join(students)}\n")

for student_name in students:
    folder = os.path.join(DATASET_PATH, student_name)
    images = [f for f in os.listdir(folder)
              if f.lower().endswith((".jpg", ".jpeg", ".png"))]
    count  = 0

    for img_name in images:
        img_path = os.path.join(folder, img_name)
        try:
            image    = face_recognition.load_image_file(img_path)
            encodings = face_recognition.face_encodings(image)
            if encodings:
                known_encodings.append(encodings[0])
                known_names.append(student_name)
                count += 1
        except Exception as e:
            print(f"  [SKIP] {img_path}: {e}")

    print(f"  ✓ {student_name}: {count}/{len(images)} images encoded")

print(f"\nTotal encodings: {len(known_encodings)}")

with open(ENCODINGS_FILE, "wb") as f:
    pickle.dump((known_encodings, known_names), f)

print(f"Saved → {ENCODINGS_FILE}")
