"""
attendance_manager.py — Core attendance logic with Present / Late / Absent timing
"""

import pandas as pd
from datetime import datetime
import os
import threading

ATTENDANCE_FILE = "attendance/attendance.csv"
PRESENT_WINDOW  = 5
LATE_WINDOW     = 15

_csv_lock = threading.Lock()

_student_records: dict = {}
_all_students: list    = []
_class_name: str       = ""
_session_start: float  = 0.0
_attendance_closed     = False


def init_session(all_students: list, class_name: str, start_time: float):
    global _all_students, _class_name, _session_start, _student_records, _attendance_closed
    _all_students      = all_students
    _class_name        = class_name
    _session_start     = start_time
    _student_records   = {}
    _attendance_closed = False

    os.makedirs("attendance", exist_ok=True)
    if not os.path.exists(ATTENDANCE_FILE):
        pd.DataFrame(columns=["Name", "Class", "Date", "Time", "Status"]).to_csv(
            ATTENDANCE_FILE, index=False, encoding="utf-8-sig")


def elapsed_minutes() -> float:
    return (datetime.now().timestamp() - _session_start) / 60.0


def record_face(name: str):
    global _attendance_closed

    if _attendance_closed:
        return None
    if name in _student_records:
        return None

    mins = elapsed_minutes()

    if mins <= PRESENT_WINDOW:
        status = "Present"
    elif mins <= LATE_WINDOW:
        status = "Late"
    else:
        return None

    _student_records[name] = {
        "status": status,
        "time":   datetime.now().strftime("%H:%M:%S"),
    }
    _write_row(name, status)
    return status


def close_attendance():
    global _attendance_closed
    if _attendance_closed:
        return
    _attendance_closed = True

    for student in _all_students:
        if student not in _student_records:
            _student_records[student] = {
                "status": "Absent",
                "time":   "-",
            }
            _write_row(student, "Absent")


def _write_row(name: str, status: str):
    row = pd.DataFrame([[
        name,
        _class_name,
        datetime.now().strftime("%d-%m-%Y"),
        datetime.now().strftime("%H:%M:%S"),
        status,
    ]], columns=["Name", "Class", "Date", "Time", "Status"])
    with _csv_lock:
        row.to_csv(ATTENDANCE_FILE, mode="a", header=False,
                   index=False, encoding="utf-8-sig")


def get_present() -> list:
    return [n for n, d in _student_records.items() if d["status"] == "Present"]

def get_late() -> list:
    return [n for n, d in _student_records.items() if d["status"] == "Late"]

def get_absent() -> list:
    return [n for n, d in _student_records.items() if d["status"] == "Absent"]

def is_closed() -> bool:
    return _attendance_closed

def get_records() -> dict:
    return dict(_student_records)


def export_report(path: str = None) -> str:
    """Export a nicely formatted Excel file with auto column widths."""
    if path is None:
        os.makedirs("reports", exist_ok=True)
        path = f"reports/report_{_class_name}_{datetime.now().strftime('%d-%m-%Y_%H-%M-%S')}.xlsx"

    rows = []
    for student in _all_students:
        rec = _student_records.get(student, {"status": "Absent", "time": "-"})
        rows.append({
            "Name":   student,
            "Class":  _class_name,
            "Date":   datetime.now().strftime("%d-%m-%Y"),
            "Time":   rec["time"],
            "Status": rec["status"],
        })

    df = pd.DataFrame(rows)

    # Write to Excel with auto column widths
    with pd.ExcelWriter(path, engine="openpyxl") as writer:
        df.to_excel(writer, index=False, sheet_name="Attendance")
        worksheet = writer.sheets["Attendance"]

        # Auto-fit every column width
        for col in worksheet.columns:
            max_len = 0
            col_letter = col[0].column_letter
            for cell in col:
                try:
                    if cell.value:
                        max_len = max(max_len, len(str(cell.value)))
                except Exception:
                    pass
            worksheet.column_dimensions[col_letter].width = max_len + 4

    return path
