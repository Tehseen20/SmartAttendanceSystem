"""
launcher.py — Professional dark-theme launcher for Smart Attendance System
"""

import tkinter as tk
import subprocess, sys, os
from datetime import datetime

# ── Palette ───────────────────────────────────────────────────────────────────
C_BG     = "#0D0D0D"
C_PANEL  = "#141414"
C_CARD   = "#1A1A1A"
C_BORDER = "#2A2A2A"
C_BLUE   = "#4A9EFF"
C_GREEN  = "#00FF88"
C_MUTED  = "#666666"
C_WHITE  = "#F0F0F0"

CLASSES = ["AI", "Physics", "Chemistry", "Programming", "Mathematics"]


class Launcher:

    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Smart Attendance — Launcher")
        self.root.configure(bg=C_BG)
        self.root.resizable(False, False)

        W, H = 520, 680
        sw = self.root.winfo_screenwidth()
        sh = self.root.winfo_screenheight()
        self.root.geometry(f"{W}x{H}+{(sw-W)//2}+{(sh-H)//2}")

        self._build_ui()
        self._tick_clock()
        self.root.mainloop()

    def _build_ui(self):
        root = self.root

        # ── Top accent bar ────────────────────────────────────────────────────
        tk.Frame(root, bg=C_BLUE, height=3).pack(fill="x")

        # ── Logo / title ──────────────────────────────────────────────────────
        hero = tk.Frame(root, bg=C_PANEL)
        hero.pack(fill="x")

        tk.Label(hero, text="◈", bg=C_PANEL, fg=C_BLUE,
                 font=("Courier New", 36)).pack(pady=(30, 4))
        tk.Label(hero, text="SMART ATTENDANCE", bg=C_PANEL, fg=C_WHITE,
                 font=("Courier New", 18, "bold")).pack()
        tk.Label(hero, text="AI-Powered Classroom Management System", bg=C_PANEL,
                 fg=C_MUTED, font=("Helvetica", 9)).pack(pady=(4, 20))

        tk.Frame(root, bg=C_BORDER, height=1).pack(fill="x")

        # ── Live clock ────────────────────────────────────────────────────────
        clock_f = tk.Frame(root, bg=C_BG)
        clock_f.pack(fill="x", pady=20, padx=30)

        self.lbl_clock = tk.Label(clock_f, text="", bg=C_BG,
                                  fg=C_BLUE, font=("Courier New", 28, "bold"))
        self.lbl_clock.pack()
        self.lbl_date = tk.Label(clock_f, text="", bg=C_BG,
                                 fg=C_MUTED, font=("Courier New", 10))
        self.lbl_date.pack()

        # ── Class selector ────────────────────────────────────────────────────
        form = tk.Frame(root, bg=C_BG)
        form.pack(fill="x", padx=30)

        tk.Label(form, text="SELECT CLASS", bg=C_BG, fg=C_MUTED,
                 font=("Courier New", 8, "bold")).pack(anchor="w", pady=(0, 4))

        self.class_var = tk.StringVar(value=CLASSES[0])
        selector_f = tk.Frame(form, bg=C_CARD)
        selector_f.pack(fill="x")

        for cls in CLASSES:
            r = tk.Frame(selector_f, bg=C_CARD)
            r.pack(fill="x")
            rb = tk.Radiobutton(r, text=cls, variable=self.class_var, value=cls,
                                bg=C_CARD, fg=C_WHITE, selectcolor=C_CARD,
                                activebackground=C_CARD, activeforeground=C_BLUE,
                                font=("Helvetica", 10),
                                indicatoron=0, relief="flat", cursor="hand2",
                                pady=7, padx=16, anchor="w")
            rb.pack(fill="x")
            rb.bind("<Enter>", lambda e, w=rb: w.config(bg="#222"))
            rb.bind("<Leave>", lambda e, w=rb: w.config(bg=C_CARD))

        # ── Info cards ────────────────────────────────────────────────────────
        info_f = tk.Frame(root, bg=C_BG)
        info_f.pack(fill="x", padx=30, pady=16)

        self._info_card(info_f, "PRESENT WINDOW", "0 – 5 min",  C_GREEN)
        self._info_card(info_f, "LATE WINDOW",    "5 – 15 min", "#FFB020")
        self._info_card(info_f, "ABSENT AFTER",   "15 min",     "#FF4444")

        for w in info_f.winfo_children():
            w.pack(side="left", expand=True, fill="both", padx=3)

        # ── START button ──────────────────────────────────────────────────────
        btn_f = tk.Frame(root, bg=C_BG)
        btn_f.pack(fill="x", padx=30, pady=(12, 4))

        # Canvas-based button for reliable height on Windows
        self.canvas_btn = tk.Canvas(btn_f, height=58, bg=C_BG,
                                    highlightthickness=0, cursor="hand2")
        self.canvas_btn.pack(fill="x")

        self._draw_start_btn(normal=True)

        self.canvas_btn.bind("<Button-1>",  lambda e: self._start())
        self.canvas_btn.bind("<Enter>",     lambda e: self._draw_start_btn(normal=False))
        self.canvas_btn.bind("<Leave>",     lambda e: self._draw_start_btn(normal=True))

        # ── Secondary buttons ─────────────────────────────────────────────────
        self._btn_flat(btn_f, "⬡  ENCODE NEW FACES", "#1E1E1E", self._encode, C_MUTED)
        self._btn_flat(btn_f, "✕  EXIT",              "#111111", self.root.destroy, C_MUTED)

        # ── Status line ───────────────────────────────────────────────────────
        self.lbl_msg = tk.Label(root, text="", bg=C_BG, fg=C_MUTED,
                                font=("Courier New", 8))
        self.lbl_msg.pack(pady=6)

    def _draw_start_btn(self, normal=True):
        c = self.canvas_btn
        c.delete("all")
        w = c.winfo_width() or 460
        h = 58
        bg    = "#1A6FD4" if normal else "#2280F0"
        # Filled rounded rectangle via polygon approximation
        r = 6
        c.create_polygon(
            r, 0,  w-r, 0,
            w, r,  w, h-r,
            w-r, h, r, h,
            0, h-r, 0, r,
            smooth=True, fill=bg, outline=""
        )
        # Play icon circle
        c.create_oval(14, 14, 40, 44, fill="#2A7AE0", outline="")
        c.create_polygon(22, 20, 22, 38, 36, 29, fill="white", outline="")
        # Text
        c.create_text(w // 2 + 10, h // 2,
                      text="START ATTENDANCE SESSION",
                      fill="white",
                      font=("Helvetica", 13, "bold"),
                      anchor="center")

    def _info_card(self, parent, title, value, color):
        f = tk.Frame(parent, bg=C_CARD)
        tk.Label(f, text=title, bg=C_CARD, fg=C_MUTED,
                 font=("Courier New", 7, "bold")).pack(pady=(8, 2))
        tk.Label(f, text=value, bg=C_CARD, fg=color,
                 font=("Courier New", 11, "bold")).pack(pady=(0, 8))
        return f

    def _btn_flat(self, parent, text, bg, cmd, fg=C_WHITE):
        b = tk.Label(parent, text=text, bg=bg, fg=fg,
                     font=("Courier New", 9, "bold"),
                     cursor="hand2", pady=9, anchor="center")
        b.pack(fill="x", pady=2)
        b.bind("<Button-1>", lambda _: cmd())
        b.bind("<Enter>",    lambda _: b.config(bg="#2A2A2A"))
        b.bind("<Leave>",    lambda _: b.config(bg=bg))

    def _tick_clock(self):
        now = datetime.now()
        self.lbl_clock.config(text=now.strftime("%H:%M:%S"))
        self.lbl_date.config(text=now.strftime("%A, %d %B %Y"))
        # Redraw button to keep size correct after window renders
        self._draw_start_btn(normal=True)
        self.root.after(1000, self._tick_clock)

    def _start(self):
        cls = self.class_var.get()
        self.lbl_msg.config(text=f"Launching session for {cls}...", fg=C_BLUE)
        self.root.after(200, lambda: self._launch(cls))

    def _launch(self, cls):
        env_copy = os.environ.copy()
        env_copy["ATTENDANCE_CLASS"] = cls
        subprocess.Popen([sys.executable, "main.py"], env=env_copy)
        self.root.after(500, lambda: self.lbl_msg.config(
            text="✓ Session launched. Launcher stays open.", fg=C_GREEN))

    def _encode(self):
        self.lbl_msg.config(text="Running face encoder...", fg=C_BLUE)
        result = subprocess.run([sys.executable, "encode_faces.py"],
                                capture_output=True, text=True)
        if result.returncode == 0:
            self.lbl_msg.config(text="✓ Encodings updated successfully.", fg=C_GREEN)
        else:
            self.lbl_msg.config(text="✗ Encoding failed. Check console.", fg="#FF4444")


if __name__ == "__main__":
    Launcher()
