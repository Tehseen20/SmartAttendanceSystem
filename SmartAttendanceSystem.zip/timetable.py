classes = {
    "AI": "14:00",
    "Physics": "10:00",
    "Chemistry": "12:00",
    "Programming": "09:00"
}

ALLOWED_MINUTES = 10