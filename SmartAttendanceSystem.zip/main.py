"""
main.py — Smart Classroom Attendance System
"""

import cv2
import face_recognition
import pickle
import numpy as np
import time
import threading
import os
import subprocess
import platform
from datetime import datetime

import tkinter as tk
from tkinter import messagebox
import attendance_manager as am

CURRENT_CLASS      = os.environ.get("ATTENDANCE_CLASS", "AI")
PRESENT_WINDOW_MIN = 5
ABSENT_WINDOW_MIN  = 15
ENCODINGS_FILE     = "encodings.pkl"

C_BG       = "#0D0D0D"
C_PANEL    = "#141414"
C_CARD     = "#1A1A1A"
C_BORDER   = "#2A2A2A"
C_PRESENT  = "#00FF88"
C_LATE     = "#FFB020"
C_ABSENT   = "#FF4444"
C_WHITE    = "#F0F0F0"
C_MUTED    = "#666666"
C_BLUE     = "#4A9EFF"
C_BLUE_DIM = "#1A3A5C"

OCV_PRESENT = (0, 255, 136)
OCV_LATE    = (0, 176, 255)
OCV_UNKNOWN = (60, 60, 255)
OCV_CLOSED  = (120, 120, 120)

PANEL_W   = 340
FONT_MONO = "Courier New"
FONT_SANS = "Helvetica"
GAP       = 8
TASKBAR_H = 80
LIST_H    = 120


class AttendanceApp:

    def __init__(self):
        self.root = tk.Tk()
        self.root.withdraw()

        if not os.path.exists(ENCODINGS_FILE):
            messagebox.showerror("Error",
                f"'{ENCODINGS_FILE}' not found.\nRun encode_faces.py first.")
            self.root.destroy()
            return

        with open(ENCODINGS_FILE, "rb") as f:
            self.known_encodings, self.known_names = pickle.load(f)

        self.all_students  = sorted(set(self.known_names))
        self.session_start = time.time()
        am.init_session(self.all_students, CURRENT_CLASS, self.session_start)

        self.cap = cv2.VideoCapture(0)
        if not self.cap.isOpened():
            messagebox.showerror("Error", "Camera not detected.")
            self.root.destroy()
            return

        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH,  640)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)

        self._running       = True
        self._welcome_queue = []
        self._new_detection = {}
        self._face_data     = []
        self._face_lock     = threading.Lock()

        self.sw       = self.root.winfo_screenwidth()
        self.sh       = self.root.winfo_screenheight()
        self.usable_h = self.sh - TASKBAR_H - GAP
        self.cam_w    = self.sw - PANEL_W - (GAP * 3)
        self.cam_h    = self.usable_h - GAP
        self.panel_h  = self.usable_h - GAP

        self._build_panel()
        self.root.deiconify()
        self.root.attributes("-topmost", True)
        self.root.update()

        threading.Thread(target=self._camera_loop, daemon=True).start()
        self.root.after(500, self._panel_tick)
        self.root.mainloop()

    # ══════════════════════════════════════════════════════════════════════════
    # SIDE PANEL
    # ══════════════════════════════════════════════════════════════════════════

    def _build_panel(self):
        self.root.title("Attendance Panel")
        self.root.configure(bg=C_BG)
        self.root.resizable(False, False)
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)

        px = self.sw - PANEL_W - GAP
        self.root.geometry(f"{PANEL_W}x{self.panel_h}+{px}+{GAP}")

        tk.Frame(self.root, bg=C_BLUE, height=3).pack(fill="x")

        # ── Header ────────────────────────────────────────────────────────────
        hdr = tk.Frame(self.root, bg=C_PANEL, height=85)
        hdr.pack(fill="x")
        hdr.pack_propagate(False)

        tk.Label(hdr, text="◈  SMART ATTENDANCE",
                 bg=C_PANEL, fg=C_BLUE,
                 font=(FONT_MONO, 10, "bold")).place(x=12, y=7)
        tk.Label(hdr, text=f"CLASS: {CURRENT_CLASS}",
                 bg=C_PANEL, fg=C_WHITE,
                 font=(FONT_SANS, 13, "bold")).place(x=12, y=28)
        self.lbl_date = tk.Label(hdr, text="", bg=C_PANEL, fg=C_MUTED,
                                  font=(FONT_MONO, 8))
        self.lbl_date.place(x=12, y=58)
        self.lbl_clock = tk.Label(hdr, text="", bg=C_PANEL, fg=C_BLUE,
                                   font=(FONT_MONO, 19, "bold"))
        self.lbl_clock.place(relx=1.0, x=-12, y=14, anchor="ne")

        tk.Frame(self.root, bg=C_BORDER, height=1).pack(fill="x")

        # ── Status bar ────────────────────────────────────────────────────────
        sbar = tk.Frame(self.root, bg=C_CARD, height=26)
        sbar.pack(fill="x")
        sbar.pack_propagate(False)
        self.lbl_status = tk.Label(sbar, text="● ATTENDANCE OPEN",
                                    bg=C_CARD, fg=C_PRESENT,
                                    font=(FONT_MONO, 8, "bold"))
        self.lbl_status.pack(side="left", padx=8)
        self.lbl_elapsed = tk.Label(sbar, text="00:00 elapsed",
                                     bg=C_CARD, fg=C_MUTED,
                                     font=(FONT_MONO, 7))
        self.lbl_elapsed.pack(side="right", padx=8)

        tk.Frame(self.root, bg=C_BORDER, height=1).pack(fill="x")

        # ── Counters ──────────────────────────────────────────────────────────
        cnt_row = tk.Frame(self.root, bg=C_BG)
        cnt_row.pack(fill="x", padx=6, pady=3)
        self.cnt_present = self._make_counter(cnt_row, "PRESENT", C_PRESENT)
        self.cnt_late    = self._make_counter(cnt_row, "LATE",    C_LATE)
        self.cnt_absent  = self._make_counter(cnt_row, "ABSENT",  C_ABSENT)
        for w in (self.cnt_present, self.cnt_late, self.cnt_absent):
            w.pack(side="left", expand=True, fill="both", padx=2)

        tk.Frame(self.root, bg=C_BORDER, height=1).pack(fill="x")

        # ── Welcome banner ────────────────────────────────────────────────────
        self.welcome_outer = tk.Frame(self.root, bg=C_BLUE_DIM, height=0)
        self.welcome_outer.pack(fill="x")
        self.welcome_outer.pack_propagate(False)
        self.lbl_welcome = tk.Label(self.welcome_outer, text="",
                                     bg=C_BLUE_DIM, fg=C_WHITE,
                                     font=(FONT_SANS, 9, "bold"))
        self.lbl_welcome.pack(pady=3)

        # ── ALL STUDENTS badges ───────────────────────────────────────────────
        all_frame = tk.Frame(self.root, bg=C_BG)
        all_frame.pack(fill="x", padx=8, pady=(3, 0))
        tk.Label(all_frame, text="◉ ALL STUDENTS", bg=C_BG, fg=C_BLUE,
                 font=(FONT_MONO, 8, "bold"), anchor="w").pack(fill="x")
        tk.Frame(all_frame, bg=C_BLUE, height=1).pack(fill="x", pady=(0, 2))
        self.badges_frame = tk.Frame(all_frame, bg=C_CARD)
        self.badges_frame.pack(fill="x", padx=2, pady=2)
        self._build_badges()

        tk.Frame(self.root, bg=C_BORDER, height=1).pack(fill="x", pady=(3, 0))

        # ── Attendance lists ──────────────────────────────────────────────────
        self.list_present = self._make_fixed_list("● PRESENT", C_PRESENT)
        self.list_late    = self._make_fixed_list("◐ LATE",    C_LATE)
        self.list_absent  = self._make_fixed_list("○ ABSENT",  C_ABSENT)

        # ── Buttons ───────────────────────────────────────────────────────────
        tk.Frame(self.root, bg=C_BORDER, height=1).pack(fill="x", pady=(3, 0))
        brow = tk.Frame(self.root, bg=C_BG)
        brow.pack(fill="x", padx=8, pady=4)

        self._make_btn(brow, "⬡  EXPORT FULL REPORT", C_BLUE,
                       self._export).pack(fill="x", pady=2)
        self._make_btn(brow, "👁  SHOW ATTENDANCE",   "#1A3A1A",
                       self._show_attendance, fg=C_PRESENT).pack(fill="x", pady=2)
        self._make_btn(brow, "✕  CLOSE SYSTEM",       "#2A2A2A",
                       self._on_close, fg=C_MUTED).pack(fill="x", pady=2)

    # ── Widget factories ──────────────────────────────────────────────────────

    def _build_badges(self):
        self._badge_labels = {}
        row_f = None
        for i, name in enumerate(self.all_students):
            if i % 2 == 0:
                row_f = tk.Frame(self.badges_frame, bg=C_CARD)
                row_f.pack(fill="x", padx=2, pady=1)
            badge = tk.Label(row_f, text=f"  {name}  ",
                             bg="#2A2A2A", fg=C_MUTED,
                             font=(FONT_SANS, 8, "bold"))
            badge.pack(side="left", padx=3, pady=2)
            self._badge_labels[name] = badge

    def _update_badges(self):
        records = am.get_records()
        for name, badge in self._badge_labels.items():
            st = records.get(name, {}).get("status", None)
            if st == "Present":
                badge.config(bg="#003D20", fg=C_PRESENT)
            elif st == "Late":
                badge.config(bg="#3D2A00", fg=C_LATE)
            elif st == "Absent":
                badge.config(bg="#3D0000", fg=C_ABSENT)
            else:
                badge.config(bg="#2A2A2A", fg=C_MUTED)

    def _make_fixed_list(self, title, color):
        outer = tk.Frame(self.root, bg=C_BG)
        outer.pack(fill="x", padx=8, pady=(2, 0))

        tk.Label(outer, text=title, bg=C_BG, fg=color,
                 font=(FONT_MONO, 8, "bold"), anchor="w").pack(fill="x")
        tk.Frame(outer, bg=color, height=1).pack(fill="x", pady=(0, 1))

        container = tk.Frame(outer, bg=C_CARD, height=LIST_H)
        container.pack(fill="x")
        container.pack_propagate(False)

        canvas = tk.Canvas(container, bg=C_CARD, highlightthickness=0)
        sb = tk.Scrollbar(container, orient="vertical", command=canvas.yview,
                          bg=C_BORDER, troughcolor=C_CARD, bd=0, width=4)
        canvas.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        canvas.pack(fill="both", expand=True)

        inner = tk.Frame(canvas, bg=C_CARD)
        wid = canvas.create_window((0, 0), window=inner, anchor="nw")

        def _resize(e):
            canvas.configure(scrollregion=canvas.bbox("all"))
            canvas.itemconfig(wid, width=canvas.winfo_width())

        inner.bind("<Configure>", _resize)
        canvas.bind("<Configure>", _resize)

        outer._inner = inner
        outer._names = []
        outer._color = color
        return outer

    def _make_counter(self, parent, label, color):
        f = tk.Frame(parent, bg=C_CARD)
        tk.Label(f, text=label, bg=C_CARD, fg=C_MUTED,
                 font=(FONT_MONO, 6, "bold")).pack(pady=(4, 0))
        v = tk.Label(f, text="0", bg=C_CARD, fg=color,
                     font=(FONT_MONO, 20, "bold"))
        v.pack(pady=(0, 4))
        f._val = v
        return f

    def _make_btn(self, parent, text, bg, cmd, fg=C_WHITE):
        b = tk.Label(parent, text=text, bg=bg, fg=fg,
                     font=(FONT_MONO, 9, "bold"),
                     cursor="hand2", pady=8, anchor="center")
        b.bind("<Button-1>", lambda _: cmd())
        b.bind("<Enter>",    lambda _: b.config(bg=self._lighten(bg)))
        b.bind("<Leave>",    lambda _: b.config(bg=bg))
        return b

    @staticmethod
    def _lighten(c):
        c = c.lstrip("#")
        try:
            r, g, b = int(c[0:2],16), int(c[2:4],16), int(c[4:6],16)
            return f"#{min(255,r+30):02x}{min(255,g+30):02x}{min(255,b+30):02x}"
        except Exception:
            return "#" + c

    # ══════════════════════════════════════════════════════════════════════════
    # PANEL TICK
    # ══════════════════════════════════════════════════════════════════════════

    def _panel_tick(self):
        if not self._running:
            return

        now  = datetime.now()
        mins = am.elapsed_minutes()

        self.lbl_clock.config(text=now.strftime("%H:%M:%S"))
        self.lbl_date.config( text=now.strftime("%a, %d %b %Y"))

        m = int(mins)
        s = int((mins - m) * 60)
        self.lbl_elapsed.config(text=f"{m:02d}:{s:02d} elapsed")

        closed = am.is_closed()
        if closed:
            self.lbl_status.config(text="⬛ ATTENDANCE CLOSED", fg=C_MUTED)
        elif mins > PRESENT_WINDOW_MIN:
            self.lbl_status.config(text="◑ LATE WINDOW", fg=C_LATE)
        else:
            self.lbl_status.config(text="● ATTENDANCE OPEN", fg=C_PRESENT)

        present = am.get_present()
        late    = am.get_late()
        absent  = am.get_absent()

        self.cnt_present._val.config(text=str(len(present)))
        self.cnt_late._val.config(   text=str(len(late)))
        self.cnt_absent._val.config( text=str(len(absent)))

        self._refresh_list(self.list_present, present)
        self._refresh_list(self.list_late,    late)
        self._refresh_list(self.list_absent,  absent)
        self._update_badges()

        ts = time.time()
        self._welcome_queue = [(n, e) for n, e in self._welcome_queue if e > ts]
        if self._welcome_queue:
            names = ", ".join(n for n, _ in self._welcome_queue[:3])
            self.lbl_welcome.config(text=f"👤  Welcome — {names}")
            self.welcome_outer.config(height=26)
        else:
            self.welcome_outer.config(height=0)

        self.root.attributes("-topmost", True)
        self.root.after(500, self._panel_tick)

    def _refresh_list(self, section, names):
        if names == section._names:
            return
        section._names = names[:]
        for w in section._inner.winfo_children():
            w.destroy()
        for n in names:
            row = tk.Frame(section._inner, bg=C_CARD)
            row.pack(fill="x", padx=4, pady=1)
            tk.Label(row, text="▸", bg=C_CARD, fg=section._color,
                     font=(FONT_MONO, 9)).pack(side="left")
            tk.Label(row, text=n, bg=C_CARD, fg=C_WHITE,
                     font=(FONT_SANS, 9)).pack(side="left", padx=4)

    # ══════════════════════════════════════════════════════════════════════════
    # CAMERA LOOP
    # ══════════════════════════════════════════════════════════════════════════

    def _camera_loop(self):
        cv2.namedWindow("Attendance Camera", cv2.WINDOW_NORMAL)
        cv2.moveWindow("Attendance Camera", GAP, GAP)
        cv2.resizeWindow("Attendance Camera", self.cam_w, self.cam_h)

        process_every = 4
        frame_count   = 0

        while self._running:
            ret, frame = self.cap.read()
            if not ret:
                break

            frame = cv2.resize(frame, (self.cam_w, self.cam_h))
            frame_count += 1
            closed = am.is_closed()

            if frame_count % process_every == 0 and not closed:
                small = cv2.resize(frame, (0, 0), fx=0.25, fy=0.25)
                rgb   = cv2.cvtColor(small, cv2.COLOR_BGR2RGB)
                locs  = face_recognition.face_locations(rgb, model="hog")
                encs  = face_recognition.face_encodings(rgb, locs)

                detected = []
                for enc, loc in zip(encs, locs):
                    matches = face_recognition.compare_faces(
                        self.known_encodings, enc, tolerance=0.5)
                    dists = face_recognition.face_distance(
                        self.known_encodings, enc)
                    name = "Unknown"
                    if len(dists) > 0:
                        idx = np.argmin(dists)
                        if matches[idx]:
                            name = self.known_names[idx]
                            status = am.record_face(name)
                            if status:
                                self._new_detection[name] = time.time() + 3.0
                                self._welcome_queue.append(
                                    (name, time.time() + 4.0))
                    rec = am.get_records().get(name, {})
                    st  = rec.get("status", "Unknown") if name != "Unknown" else "Unknown"
                    detected.append((loc, name, st))

                with self._face_lock:
                    self._face_data = detected

            with self._face_lock:
                faces = list(self._face_data)

            for loc, name, st in faces:
                top, right, bottom, left = [v * 4 for v in loc]
                glow = time.time() < self._new_detection.get(name, 0)

                if closed:
                    color, thick = OCV_CLOSED, 1
                elif st == "Present":
                    color, thick = OCV_PRESENT, 3 if glow else 2
                elif st == "Late":
                    color, thick = OCV_LATE, 3 if glow else 2
                else:
                    color, thick = OCV_UNKNOWN, 1

                self._corner_box(frame, left, top, right, bottom, color, thick)
                label = name if name != "Unknown" else "? Unknown"
                (tw, th), _ = cv2.getTextSize(
                    label, cv2.FONT_HERSHEY_SIMPLEX, 0.6, 1)
                cv2.rectangle(frame,
                              (left, top - th - 14),
                              (left + tw + 10, top), color, -1)
                cv2.putText(frame, label, (left + 5, top - 5),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.6,
                            (0, 0, 0), 1, cv2.LINE_AA)
                if st not in ("Unknown", ""):
                    cv2.putText(frame, st, (left + 5, bottom + 20),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.55,
                                color, 1, cv2.LINE_AA)

            h, w = frame.shape[:2]
            bar = frame.copy()
            cv2.rectangle(bar, (0, 0), (w, 52), (13, 13, 13), -1)
            cv2.addWeighted(bar, 0.82, frame, 0.18, 0, frame)

            cv2.putText(frame, f"CLASS: {CURRENT_CLASS}",
                        (14, 34), cv2.FONT_HERSHEY_SIMPLEX, 0.8,
                        (180, 180, 180), 1, cv2.LINE_AA)

            clock_str = datetime.now().strftime("%H:%M:%S")
            (cl, _), _ = cv2.getTextSize(clock_str, cv2.FONT_HERSHEY_SIMPLEX, 1.0, 2)
            cv2.putText(frame, clock_str, (w // 2 - cl // 2, 36),
                        cv2.FONT_HERSHEY_SIMPLEX, 1.0, (74, 158, 255), 2, cv2.LINE_AA)

            mins = am.elapsed_minutes()
            if closed:
                tag, tcol = "ATTENDANCE CLOSED", OCV_CLOSED
            elif mins <= PRESENT_WINDOW_MIN:
                tag, tcol = f"PRESENT  {int(PRESENT_WINDOW_MIN-mins)+1}m left", OCV_PRESENT
            elif mins <= ABSENT_WINDOW_MIN:
                tag, tcol = f"LATE  {int(ABSENT_WINDOW_MIN-mins)+1}m left", OCV_LATE
            else:
                tag, tcol = "CLOSING...", (60, 60, 255)

            (tl, _), _ = cv2.getTextSize(tag, cv2.FONT_HERSHEY_SIMPLEX, 0.65, 1)
            cv2.putText(frame, tag, (w - tl - 14, 34),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.65, tcol, 1, cv2.LINE_AA)

            bbar = frame.copy()
            cv2.rectangle(bbar, (0, h - 44), (w, h), (13, 13, 13), -1)
            cv2.addWeighted(bbar, 0.82, frame, 0.18, 0, frame)

            cv2.putText(frame, f"PRESENT: {len(am.get_present())}",
                        (14, h-14), cv2.FONT_HERSHEY_SIMPLEX, 0.65, OCV_PRESENT, 1, cv2.LINE_AA)
            cv2.putText(frame, f"LATE: {len(am.get_late())}",
                        (200, h-14), cv2.FONT_HERSHEY_SIMPLEX, 0.65, OCV_LATE, 1, cv2.LINE_AA)
            cv2.putText(frame, f"ABSENT: {len(am.get_absent())}",
                        (360, h-14), cv2.FONT_HERSHEY_SIMPLEX, 0.65, (60,60,255), 1, cv2.LINE_AA)
            cv2.putText(frame, f"TOTAL: {len(self.all_students)}",
                        (520, h-14), cv2.FONT_HERSHEY_SIMPLEX, 0.65, (180,180,180), 1, cv2.LINE_AA)

            cv2.imshow("Attendance Camera", frame)

            if mins >= ABSENT_WINDOW_MIN and not closed:
                am.close_attendance()

            if cv2.waitKey(1) & 0xFF == 27:
                break

        self.cap.release()
        cv2.destroyAllWindows()
        self._running = False
        try:
            self.root.quit()
        except Exception:
            pass

    @staticmethod
    def _corner_box(img, x1, y1, x2, y2, color, thick):
        L = min(28, (x2-x1)//4, (y2-y1)//4)
        for p1, corner, p2 in [
            ((x1, y1+L),   (x1,y1), (x1+L,y1)),
            ((x2-L, y1),   (x2,y1), (x2,y1+L)),
            ((x2, y2-L),   (x2,y2), (x2-L,y2)),
            ((x1+L, y2),   (x1,y2), (x1,y2-L)),
        ]:
            cv2.line(img, p1, corner, color, thick, cv2.LINE_AA)
            cv2.line(img, corner, p2, color, thick, cv2.LINE_AA)

    # ══════════════════════════════════════════════════════════════════════════
    # ACTIONS
    # ══════════════════════════════════════════════════════════════════════════

    def _export(self):
        path = am.export_report()
        messagebox.showinfo("Report Saved", f"Saved to:\n{os.path.abspath(path)}")
        try:
            if platform.system() == "Windows":
                os.startfile(os.path.abspath(path))
            elif platform.system() == "Darwin":
                subprocess.call(["open", path])
            else:
                subprocess.call(["xdg-open", path])
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def _show_attendance(self):
        try:
            import openpyxl
            from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
        except ImportError:
            messagebox.showerror("Error",
                "openpyxl not installed.\nRun: pip install openpyxl")
            return

        os.makedirs("reports", exist_ok=True)
        path = f"reports/summary_{CURRENT_CLASS}_{datetime.now().strftime('%d-%m-%Y_%H-%M-%S')}.xlsx"

        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "Attendance Summary"

        # Header row
        ws.append(["Name", "Status"])
        for cell in ws[1]:
            cell.font      = Font(bold=True, color="FFFFFF", size=11)
            cell.fill      = PatternFill("solid", fgColor="1A6FD4")
            cell.alignment = Alignment(horizontal="center")

        # Student rows
        color_map = {
            "Present": ("00AA55", "E6FFF2"),
            "Late":    ("CC8800", "FFF8E6"),
            "Absent":  ("CC2222", "FFE6E6"),
        }
        records = am.get_records()

        for student in self.all_students:
            st    = records.get(student, {}).get("status", "Absent")
            fg, bg = color_map.get(st, ("888888", "F0F0F0"))
            ws.append([student, st])
            row = ws.max_row
            ws[f"A{row}"].alignment = Alignment(horizontal="left")
            ws[f"B{row}"].font      = Font(bold=True, color=fg)
            ws[f"B{row}"].fill      = PatternFill("solid", fgColor=bg)
            ws[f"B{row}"].alignment = Alignment(horizontal="center")

        # Column widths
        ws.column_dimensions["A"].width = 22
        ws.column_dimensions["B"].width = 14

        wb.save(path)

        try:
            if platform.system() == "Windows":
                os.startfile(os.path.abspath(path))
            elif platform.system() == "Darwin":
                subprocess.call(["open", path])
            else:
                subprocess.call(["xdg-open", path])
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def _on_close(self):
        self._running = False
        try:
            self.cap.release()
            cv2.destroyAllWindows()
        except Exception:
            pass
        try:
            self.root.destroy()
        except Exception:
            pass


if __name__ == "__main__":
    AttendanceApp()
